% Load dataset
% CMPE 425 - Assignment 1
% Muyi Omorogbe - 20220300
% February 19, 2025

load('assignment1.mat'); 

% Get dataset dimensions
[D, N, K] = size(digits_train);  % D = 64 features, N = 700 samples per class, K = 10 classes
M = K * N; % Total number of training samples

% Compute class means µ_k (each row corresponds to a class mean)
mu_k = zeros(K, D); 
for k = 1:K
    mu_k(k, :) = mean(digits_train(:, :, k), 2)'; % Compute mean along second axis (samples)
end

% Load the dataset into memory
load('assignment1.mat'); % Ensure this file is available in the working directory

% Retrieve dataset dimensions
[D, N, K] = size(digits_train);  % D: 64 features, N: 700 samples per class, K: 10 classes
M = K * N; % Total number of training samples across all classes

% ----------------------------------------------
% Maximum Likelihood Estimation (MLE) of Mean µ_k
% ----------------------------------------------
% Compute the MLE estimate of the mean µ_k for each class k
mu_k = zeros(K, D); % Placeholder for mean vectors of each class
for k = 1:K
    mu_k(k, :) = mean(digits_train(:, :, k), 2)'; % Compute mean feature values for class k
end

% ----------------------------------------------
% Compute Shared Variance (σ²) Across All Classes
% ----------------------------------------------
sigma_squared = 0;
for k = 1:K
    for j = 1:N
        sigma_squared = sigma_squared + sum((digits_train(:, j, k) - mu_k(k, :)').^2);
    end
end
sigma_squared = sigma_squared / (D * M); % Normalize by total feature count

% ----------------------------------------------
% Visualization: Display Class Mean Images (8x8)
% ----------------------------------------------
figure;
for k = 1:K
    subplot(2, 5, k);
    imagesc(reshape(mu_k(k, :), 8, 8)'); % Convert vector back to 8x8 matrix
    axis equal;
    axis off;
    colormap gray;
    title(['Class ', num2str(mod(k, 10))]); % Adjust label to display 0 as the last digit
end
sgtitle('Mean Images for Each Class'); % Set overall title for figure

% ----------------------------------------------
% Output Results: Print Shared Variance σ²
% ----------------------------------------------
fprintf('Estimated shared variance (σ^2): %.6f\n', sigma_squared);
