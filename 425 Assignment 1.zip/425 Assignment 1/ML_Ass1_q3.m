% CMPE 425 - Assignment 1
% Muyi Omorogbe - 20220300
% February 19, 2025

load 'assignment1.mat'
% The following code is rewritten from Q1 and Q2 to better test performance

%Training gaussian from Q1 
for j = 1:10
    for i = 1:64
        mle(i,j) = sum(digits_train(i,:,j))/700
    end
end
% fix shape of mle
mle2 = reshape(mle,64,1,10)
mle2 = repmat(mle2,1,700,1)
s2 = sum((digits_train - mle2).^2, 'all') / (64 * 7000);

%Training Naive Bayes Classifiers from Q2
% convert training data to binary values with threshold using fix
digits_train_binary = (digits_train>0.5)

eta = sum(digits_train_binary(:,:,:),2)./ 700
m_eta = 1-eta
% ----------------------------------------------








%Part 3 actually testing and recording error rates








% ----------------------------------------------
% gaussian test - p(C_k|x) = p(x|C_k)*p(C_k)
% ----------------------------------------------

t1 = (2*pi*s2)^-32
t2 = (-1/(2*s2)) 

for i = 1:10
    gaussian_test(i,:,:) = ((t1 .* exp(t2 .* sum((digits_test(:,:,:) - mle(:,i)).^2))).*(1/10));
    % bayes theorem
end

% normalize so that each data point sums to 1
gaussian_test(:,:,:) = gaussian_test(:,:,:)./sum(gaussian_test)

% select most likely class for each data point
for i = 1:10
    [mx, idx] = max(gaussian_test(:,:,i), [], 1)
    gaussian_errs(i) = nnz(idx - i)
end
% ----------------------------------------------
% naive bayes p(C_k|x) = p(b|C_k,eta) * p(C_k) = Prod(eta * (1 - eta)) * 1/10
% ----------------------------------------------
digits_test_binary = (digits_test>0.5)

for i = 1:10
    eta_combined = m_eta(:,1,i) .* (digits_test_binary==0)    % convert data_test_binary matrix so it contains eta or 1-eta
    eta_combined_p = eta(:,1,i) .* (digits_test_binary==1)
    eta_combined(eta_combined == 0) = eta_combined_p(eta_combined==0)
    temp = reshape(prod(eta_combined),1,400,10)
    naive_test(i,:,:) = temp
end

naive_test(:,:,:) = naive_test(:,:,:)./sum(naive_test)

for i = 1:10
    [mx, idx] = max(naive_test(:,:,i), [], 1)
    naive_errs(i) = nnz(idx - i)
end

gaussian_errors_total = sum(gaussian_errs) / 4000;
naive_errors_total = sum(naive_errs) / 4000;
