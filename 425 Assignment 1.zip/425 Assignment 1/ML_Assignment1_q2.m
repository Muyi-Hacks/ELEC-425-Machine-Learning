% CMPE 425 - Assignment 1
% Muyi Omorogbe - 20220300
% February 19, 2025

% Load the dataset into memory
load('assignment1.mat'); 

% Retrieve dataset dimensions
[D, N, K] = size(digits_train);  % D: 64 features, N: 700 samples per class, K: 10 classes

% ----------------------------------------------
% Convert Real-Valued Features to Binary Features (b)
% ----------------------------------------------
% Apply thresholding: b_i = 1 if x_i > 0.5, otherwise b_i = 0
binary_train = digits_train > 0.5; % Convert all training data to binary representation

% ----------------------------------------------
% Compute Prior Probabilities p(C_k)
% ----------------------------------------------
% Since all classes have an equal number of samples, we set:
alpha_k = 1 / K; % Each class has equal probability

% ----------------------------------------------
% Maximum Likelihood Estimation (MLE) for η_ki
% ----------------------------------------------
% Compute the MLE estimate of η_ki = p(b_i = 1 | C_k)
eta_k = zeros(K, D); % Placeholder for probability parameters
for k = 1:K
    eta_k(k, :) = mean(binary_train(:, :, k), 2)'; % Compute mean occurrence of 1s for each feature
end

% ----------------------------------------------
% Visualization: Display Class Probability Images (η_k)
% ----------------------------------------------
figure;
for k = 1:K
    subplot(2, 5, k);
    imagesc(reshape(eta_k(k, :), 8, 8)'); % Convert vector back to 8x8 matrix
    axis equal;
    axis off;
    colormap gray;
    title(['Class ', num2str(mod(k, 10))]); % Adjust label to display 0 as the last digit
end
sgtitle('Naive Bayes Feature Probabilities (η_k)');

% ----------------------------------------------
% Output Results: Print Prior Probability α_k
% ----------------------------------------------
fprintf('Prior probability (p(C_k)): %.2f\n', alpha_k);
