clear all;

% Load data
load data;

% Run K-medoids clustering with different numbers of clusters
%disp('Running K-medoids with 2 clusters...');
%k_medoids(data, 2);
%pause(2);

%disp('Running K-medoids with 3 clusters...');
%k_medoids(data, 3);
%pause(2);

disp('Running K-medoids with 4 clusters...');
k_medoids(data, 4);
