clear all;

% Load data
load data;

% Run K-medians clustering with different numbers of clusters in mind

%disp('Running K-medians with 2 clusters...');
%k_medians(data, 2);
%pause(2);

%disp('Running K-medians with 3 clusters...');
%k_medians(data, 3);
%pause(2);

disp('Running K-medians with 4 clusters...');
k_medians(data, 4);
