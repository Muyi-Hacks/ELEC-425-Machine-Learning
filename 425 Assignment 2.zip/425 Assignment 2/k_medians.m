function [membership, centres] = k_medians(X, n_cluster)
% X: the data matrix, rows are data points and columns are features
% n_cluster: number of clusters

if n_cluster > 4
    disp('You have set too many clusters.');
    disp('Set the number of clusters to be 1-4.');
    disp('The program and visualization allow for up to 4 clusters.');
    return;
end

% Initialize figure
figure('position', [200, 200, 600, 500]);

% Get the number of data points and features
[n_sample, n_feat] = size(X);

% Randomly initialize the starting cluster centres
rng('shuffle');
up_bound = max(X);
lw_bound = min(X);
centres = lw_bound + (up_bound - lw_bound) .* rand(n_cluster, n_feat);

disp('Start K-medians clustering ... ');

% Initialize cluster membership
old_membership = ones(n_sample, 1);

% Display initial cluster assignment
show(X, old_membership, n_cluster, centres, 'Cluster Centres are Marked with X');

while true
    % Compute Manhattan (city block) distance between each point and each cluster center
    distance = pdist2(X, centres, 'cityblock');

    % Assign data points to the closest cluster
    [~, membership] = min(distance, [], 2);

    % Display results after assignment
    show(X, membership, n_cluster, centres, 'E Step: Data Reassigned!');

    % Update cluster centers using the median
    for j = 1:n_cluster
        if sum(membership == j) > 0
            centres(j, :) = median(X(membership == j, :), 1);
        end
    end

    % Display updated cluster centers
    show(X, membership, n_cluster, centres, 'M Step: Clusters Updated!');

    % Stop if no updates
    if sum(membership ~= old_membership) == 0
        show(X, membership, n_cluster, centres, 'Done!');
        break;
    end

    old_membership = membership;
end
end

% ==========================
% Visualization Function
% ==========================
function show(X, c_pred, n_cluster, centres, txt)
    % Define distinct markers and colors for clusters
    symbols = {'ro', 'g*', 'bd', 'k^', 'ms'}; % Different shapes for clarity
    center_symbols = {'rx', 'gx', 'bx', 'kx', 'mx'}; % Crosses for centers

    hold off;

    for i = 1:n_cluster
        marker = mod(i - 1, length(symbols)) + 1;  % Ensure valid indexing

        % Plot data points assigned to cluster i
        plot(X(c_pred == i, 1), X(c_pred == i, 2), symbols{marker}, 'MarkerSize', 6, 'LineWidth', 1);
        hold on;

        % Plot cluster centers with larger filled markers
        plot(centres(i, 1), centres(i, 2), center_symbols{marker}, 'MarkerSize', 12, 'LineWidth', 2);

        % Annotate cluster centers with coordinates
        text(centres(i, 1) + 0.1, centres(i, 2), sprintf('X %.1f\nY %.1f', centres(i, 1), centres(i, 2)), ...
            'FontSize', 10, 'FontWeight', 'bold', 'BackgroundColor', 'w', 'EdgeColor', 'k');
    end

    % Display status text on the plot
    text(min(X(:,1)), max(X(:,2)), txt, 'FontSize', 12, 'FontWeight', 'bold');

    drawnow;
    pause(2);
end
