function [membership, centres] = k_medoids(X, n_cluster)
% X: the data matrix, rows are data points and columns are features
% n_cluster: number of clusters

if n_cluster > 4
    disp('You have set too many clusters.');
    disp('Set the number of clusters to be 1-4.');
    disp('The program and visualization allow for up to 4 clusters.');
    return;
end

% Initialize figure
figure('position', [200, 200, 600, 500]);

% Get number of data points and features
[n_sample, n_feat] = size(X);

% Randomly select initial medoids (must be actual data points)
rng('shuffle');
rand_indices = randperm(n_sample, n_cluster);
centres = X(rand_indices, :);

disp('Start K-medoids clustering ... ');

% Initialize cluster membership
old_membership = ones(n_sample, 1);

% Display initial cluster assignment
show(X, old_membership, n_cluster, centres, 'Cluster Centres are marked with X');

while true
    % Compute Manhattan (city block) distance between each point and each cluster center
    distance = pdist2(X, centres, 'cityblock');

    % Assign data points to the closest cluster
    [~, membership] = min(distance, [], 2);

    % Display results after assignment
    show(X, membership, n_cluster, centres, 'E Step: Data Reassigned!');

    % M-Step: Find the best medoid for each cluster
    for j = 1:n_cluster
        cluster_points = X(membership == j, :);
        if size(cluster_points, 1) > 0
            % Compute sum of Manhattan distances for each point in cluster
            cost_matrix = pdist2(cluster_points, cluster_points, 'cityblock');
            total_distances = sum(cost_matrix, 2);
            
            % Select the data point with the smallest total distance as the new medoid
            [~, min_idx] = min(total_distances);
            centres(j, :) = cluster_points(min_idx, :);
        end
    end

    % Display updated cluster centers
    show(X, membership, n_cluster, centres, 'M Step: Clusters Updated!');

    % Stop if no updates
    if sum(membership ~= old_membership) == 0
        show(X, membership, n_cluster, centres, 'Done!');
        break;
    end

    old_membership = membership;
end
end

% ==========================
% Visualization Function
% ==========================
function show(X, c_pred, n_cluster, centres, txt)
    % Define distinct markers and colors for clusters
    symbols = {'ro', 'g*', 'bd', 'k^', 'ms'}; % Different shapes for clarity
    center_symbols = {'rx', 'gx', 'bx', 'kx', 'mx'}; % Crosses for medoids

    hold off;

    for i = 1:n_cluster
        marker = mod(i - 1, length(symbols)) + 1;  % Ensure valid indexing

        % Plot data points assigned to cluster i
        plot(X(c_pred == i, 1), X(c_pred == i, 2), symbols{marker}, 'MarkerSize', 6, 'LineWidth', 1);
        hold on;

        % Plot cluster medoids with larger filled markers
        plot(centres(i, 1), centres(i, 2), center_symbols{marker}, 'MarkerSize', 12, 'LineWidth', 2);

        % Annotate cluster medoids with coordinates
        text(centres(i, 1) + 0.1, centres(i, 2), sprintf('X %.1f\nY %.1f', centres(i, 1), centres(i, 2)), ...
            'FontSize', 10, 'FontWeight', 'bold', 'BackgroundColor', 'w', 'EdgeColor', 'k');
    end

    % Display status text on the plot
    text(min(X(:,1)), max(X(:,2)), txt, 'FontSize', 12, 'FontWeight', 'bold');

    drawnow;
    pause(2);
end
