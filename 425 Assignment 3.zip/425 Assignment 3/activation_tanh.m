function y = activation_tanh(alpha)
    y = tanh(alpha);
end